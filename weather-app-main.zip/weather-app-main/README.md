## Notes when runing the app
After downloading open command prompt, navigate to the `weather-app/weather-app` directory and use the command `npm install`, finally use `npm run dev` command to run the app in developer mode.
## App features


## How to Run the App 

## First time Running the App
After downloading, open command prompt and then TYPE THE FOLLOWING COMMANDS
1. SET PATH=C:\Program Files\Nodejs;%PATH%
2. npm uninstall -g vite
3. Navigate to the `weather-app/weather-app` directory
- cd downloads
- cd weather-app-main
- cd weather-app-main
- cd weather-app
4. npm install
5. npm run dev
## Running the App after the First time
1. Navigate to the `weather-app/weather-app` directory
- cd downloads
- cd weather-app-main
- cd weather-app-main
- cd weather-app
2. npm run dev
